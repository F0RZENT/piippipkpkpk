﻿using UdpServer;

class Program
{
    public static void Main(string[] args)
    {
        Server.AcceptMessage();


    }
}
