var searchData=
[
  ['button1_0',['button1',['../classprocess_1_1_form1.html#a78dc5d579d51a8cd54a59bd5cbb7ef21',1,'process.Form1.button1'],['../classprocess_1_1_form2.html#a00de0301a298e0bba617d5fb78daa80d',1,'process.Form2.button1']]],
  ['button2_1',['button2',['../classprocess_1_1_form1.html#a6db604d8b5ba559c4f723aae4237ed2c',1,'process.Form1.button2'],['../classprocess_1_1_form2.html#a949eb412f3590a3723d0ae278e3b8c3e',1,'process.Form2.button2']]]
];
