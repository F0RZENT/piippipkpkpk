var searchData=
[
  ['components_0',['components',['../classprocess_1_1_form1.html#a9b19dfd55a749e8edc8499f92e600c25',1,'process.Form1.components'],['../classprocess_1_1_form2.html#a3bd1fce9d427f6ca47a610cd37653575',1,'process.Form2.components']]]
];
