var searchData=
[
  ['выходtoolstripmenuitem_0',['выходToolStripMenuItem',['../classprocess_1_1_form1.html#a1d4efa3fd437f0a0e7aafe6523023c20',1,'process::Form1']]]
];
