var searchData=
[
  ['button1_5fclick_0',['button1_Click',['../classprocess_1_1_form1.html#a080740ee11a6b2e0991abbaa599ccff7',1,'process.Form1.button1_Click()'],['../classprocess_1_1_form2.html#a1b57a990dcc89e6b28baea089a5f3e41',1,'process.Form2.button1_Click()']]],
  ['button2_5fclick_1',['button2_Click',['../classprocess_1_1_form1.html#ad592557aec43eefc84b232a0ce3b83be',1,'process.Form1.button2_Click()'],['../classprocess_1_1_form2.html#a9eb3e9f6710fc81381fc8b13ab0d6e63',1,'process.Form2.button2_Click()']]]
];
