var searchData=
[
  ['функцииtoolstripmenuitem_0',['функцииToolStripMenuItem',['../classprocess_1_1_form1.html#afe54184f083a69b733900d0e7d2a4a2f',1,'process::Form1']]]
];
