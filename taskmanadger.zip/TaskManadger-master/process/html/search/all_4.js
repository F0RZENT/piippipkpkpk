var searchData=
[
  ['initializecomponent_0',['InitializeComponent',['../classprocess_1_1_form1.html#a3cb1c877bd167cf71b525dfc2ff8c81a',1,'process.Form1.InitializeComponent()'],['../classprocess_1_1_form2.html#a66fbbd3a44fe572215c49975e0c6e8e5',1,'process.Form2.InitializeComponent()']]]
];
