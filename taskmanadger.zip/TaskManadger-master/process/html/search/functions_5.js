var searchData=
[
  ['textbox1_5ftextchanged_0',['textBox1_TextChanged',['../classprocess_1_1_form1.html#a30893a86fbaf677768bb8de1737fe586',1,'process.Form1.textBox1_TextChanged()'],['../classprocess_1_1_form2.html#a3ed929c3695f137ee66fbc6990179a94',1,'process.Form2.textBox1_TextChanged()']]],
  ['timer1_5ftick_1',['timer1_Tick',['../classprocess_1_1_form1.html#a8b57b49439855edbd6b3915edfba1df6',1,'process::Form1']]]
];
