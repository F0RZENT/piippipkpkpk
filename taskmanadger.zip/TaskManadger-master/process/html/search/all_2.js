var searchData=
[
  ['dispose_0',['Dispose',['../classprocess_1_1_form1.html#af78e14feb74940d74ded2e5e4f9e120b',1,'process.Form1.Dispose()'],['../classprocess_1_1_form2.html#a84f718bcbe80a47d360e29ab4cc64eb3',1,'process.Form2.Dispose()']]]
];
